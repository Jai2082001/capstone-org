const Home = () => {
    return (
        <div>    
            The Organization End
        </div>
    )   
}

export default Home;